
pRead = open("..\\bate\\wordlist.txt")
pWrite = open("..\\bate\\hmmstatelist.txt")

for word in (pRead):
    print "please input the state of " + word + " : "
